//
//  Regen.h
//  Regen
//
//  Created by Regen on 1/29/23.
//

#import <Foundation/Foundation.h>

//! Project version number for Regen.
FOUNDATION_EXPORT double RegenVersionNumber;

//! Project version string for Regen.
FOUNDATION_EXPORT const unsigned char RegenVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Regen/PublicHeader.h>


